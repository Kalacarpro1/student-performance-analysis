"""
Student Performance Analysis System
====================================
Main entry point — calls all preprocessing and analysis steps in order.
"""

import os
import sys

# Allow imports from src/
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from preprocess import load_dataset, handle_missing_values, remove_outliers, feature_engineering
from analysis import (
    basic_statistics,
    top_students,
    low_performers,
    group_analysis,
    study_vs_marks,
    attendance_vs_marks,
    extract_insights,
)

DATASET_PATH = os.path.join(os.path.dirname(__file__), 'data', 'student_dataset.csv')


def main():
    print("\n" + "🎓" * 25)
    print("   STUDENT PERFORMANCE ANALYSIS SYSTEM")
    print("🎓" * 25)

    # ── Step 1: Load Data ──────────────────────────────────
    df = load_dataset(DATASET_PATH)

    # ── Step 2: Handle Missing Values ─────────────────────
    df = handle_missing_values(df)

    # ── Step 3: Remove Outliers ────────────────────────────
    df = remove_outliers(df)

    # ── Step 4: Feature Engineering ───────────────────────
    df = feature_engineering(df)

    # ── Step 5: Basic Statistics ───────────────────────────
    basic_statistics(df)

    # ── Step 6: Top Students ───────────────────────────────
    top_students(df, n=5)

    # ── Step 7: Low Performers ─────────────────────────────
    low_performers(df, threshold=50)

    # ── Step 8: Study Hours vs Marks ──────────────────────
    study_vs_marks(df)

    # ── Step 9: Attendance vs Marks ────────────────────────
    attendance_vs_marks(df)

    # ── Step 10: Group Analysis ────────────────────────────
    group_analysis(df)

    # ── Step 11: Insights ──────────────────────────────────
    extract_insights(df)

    print("\n" + "=" * 50)
    print("✅  ANALYSIS COMPLETE")
    print("=" * 50 + "\n")


if __name__ == '__main__':
    main()
